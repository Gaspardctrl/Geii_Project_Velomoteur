VESC – Open Source ESC
=============

This the Hardware for my open source custom ESC.

## Schematic top level
![alt tag](design/PNGs/Schematic-1.png)

## Layout -made with KiCad!-
![alt tag](design/PNGs/layout_4.12.png)

## 3D views
![alt tag](design/PNGs/3D_front.png)
![alt tag](design/PNGs/3D_back.png)

Update: The BOM is no longer available on google docs, it is included in the design folder as an .ods file.

Have a look at this post for a tutorial on how to get started:
http://vedder.se/2015/01/vesc-open-source-esc/

VESC Hardware is licensed under the Creative Commons Attribution-ShareAlike 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/4.0/.
